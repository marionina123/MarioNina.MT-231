#!/bin/bash
echo "Usuario ingrese su nombre: "
read usuario
echo "Saludos usuario"
mkdir ubicaciones
cd ubicaciones
pwd >> ubicacion.txt
date >> fechaTarea3.txt
cd -
ls -l 
echo "Se ha finalizado el script."
